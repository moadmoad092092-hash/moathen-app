import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.moathen.app',
  appName: 'مؤذّن | Moathen',
  webDir: 'dist',
  android: { allowMixedContent: false },
  plugins: {
    Geolocation: { permissions: ['location'] },
  },
};

export default config;
