import { registerPlugin } from '@capacitor/core';

export interface ScheduleConfiguration {
  cityId: string;
  latitude: number;
  longitude: number;
  timeZone: string;
  calculationMethod: string;
  prayers: Record<string, { enabled: boolean; audioFile: string }>;
}

export interface PermissionState {
  exactAlarmsAllowed: boolean;
  notificationAllowed: boolean;
}

export interface MoathenSchedulerPlugin {
  scheduleAll(options: ScheduleConfiguration): Promise<PermissionState & { scheduled: number }>;
  getPermissionState(): Promise<PermissionState>;
  requestExactAlarmPermission(): Promise<{ openedSettings: boolean }>;
  requestNotificationPermission(): Promise<{ granted: boolean }>;
}

export const MoathenScheduler = registerPlugin<MoathenSchedulerPlugin>('MoathenScheduler');
