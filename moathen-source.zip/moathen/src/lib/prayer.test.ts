import { describe, expect, it } from 'vitest';
import { CITIES } from './cities';
import { formatClock, formatCountdown, getNextPrayer, getPrayerTimes } from './prayer';

describe('prayer time calculation', () => {
  it('returns five real prayer instants in chronological order for Mecca', () => {
    const city = CITIES.find((item) => item.id === 'makkah')!;
    const times = getPrayerTimes(city, new Date('2026-10-12T09:00:00Z'), 'UmmAlQura');
    expect(times).toHaveLength(5);
    expect(times.every((item) => Number.isFinite(item.date.getTime()))).toBe(true);
    expect(times.every((item, index) => index === 0 || item.date > times[index - 1].date)).toBe(true);
  });

  it('formats the chosen city timezone independently of the host timezone', () => {
    expect(formatClock(new Date('2026-10-12T12:00:00Z'), 'Asia/Riyadh')).toBe('15:00');
    expect(formatClock(new Date('2026-10-12T12:00:00Z'), 'America/New_York')).toContain(':');
  });

  it('finds the upcoming prayer and rolls to tomorrow after Isha', () => {
    const city = CITIES.find((item) => item.id === 'cairo')!;
    const next = getNextPrayer(city, 'Egyptian', new Date('2026-10-12T00:00:00Z'));
    expect(next.key).toBe('fajr');
    const late = getNextPrayer(city, 'Egyptian', new Date('2026-10-12T23:59:00Z'));
    expect(late.key).toBe('fajr');
    expect(late.date.getTime()).toBeGreaterThan(new Date('2026-10-12T23:59:00Z').getTime());
  });

  it('formats a stable countdown', () => {
    expect(formatCountdown(new Date('2026-10-12T13:00:00Z'), new Date('2026-10-12T12:01:02Z'))).toBe('00:58:58');
  });
});
