export const PRAYERS = [
  { key: 'fajr', label: 'الفجر', nativeKey: 'FAJR' },
  { key: 'dhuhr', label: 'الظهر', nativeKey: 'DHUHR' },
  { key: 'asr', label: 'العصر', nativeKey: 'ASR' },
  { key: 'maghrib', label: 'المغرب', nativeKey: 'MAGHRIB' },
  { key: 'isha', label: 'العشاء', nativeKey: 'ISHA' },
] as const;

export type PrayerKey = (typeof PRAYERS)[number]['key'];
export type CalculationMethodKey =
  | 'MWL' | 'Egyptian' | 'UmmAlQura' | 'Karachi' | 'Dubai' | 'Qatar' | 'Kuwait' | 'NorthAmerica' | 'Singapore' | 'Turkey' | 'MoonsightingCommittee';

export interface City {
  id: string;
  name: string;
  country: string;
  latitude: number;
  longitude: number;
  timeZone: string;
}

export type AudioChoice = 'beautiful' | 'andrewler';

export interface AppSettings {
  city: City;
  calculationMethod: CalculationMethodKey;
  enabled: Record<PrayerKey, boolean>;
  audio: Record<PrayerKey, AudioChoice>;
  webAudioEnabled: boolean;
}

export interface PrayerTimeItem {
  key: PrayerKey;
  label: string;
  date: Date;
}
