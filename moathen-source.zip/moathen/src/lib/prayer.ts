import { CalculationMethod, Coordinates, PrayerTimes } from 'adhan';
import type { AppSettings, CalculationMethodKey, City, PrayerKey, PrayerTimeItem } from './types';
import { PRAYERS } from './types';

const methods = {
  MWL: CalculationMethod.MuslimWorldLeague,
  Egyptian: CalculationMethod.Egyptian,
  UmmAlQura: CalculationMethod.UmmAlQura,
  Karachi: CalculationMethod.Karachi,
  Dubai: CalculationMethod.Dubai,
  Qatar: CalculationMethod.Qatar,
  Kuwait: CalculationMethod.Kuwait,
  NorthAmerica: CalculationMethod.NorthAmerica,
  Singapore: CalculationMethod.Singapore,
  Turkey: CalculationMethod.Turkey,
  MoonsightingCommittee: CalculationMethod.MoonsightingCommittee,
} satisfies Record<CalculationMethodKey, () => ReturnType<typeof CalculationMethod.MuslimWorldLeague>>;

const timeFields: Record<PrayerKey, keyof PrayerTimes> = {
  fajr: 'fajr', dhuhr: 'dhuhr', asr: 'asr', maghrib: 'maghrib', isha: 'isha',
};

export function datePartsInZone(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(date);
  const part = (type: string) => Number(parts.find((item) => item.type === type)?.value);
  return { year: part('year'), month: part('month'), day: part('day') };
}

export function dateForZoneDay(date: Date, timeZone: string, offsetDays = 0): Date {
  const { year, month, day } = datePartsInZone(date, timeZone);
  const shifted = new Date(Date.UTC(year, month - 1, day + offsetDays, 12));
  return new Date(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate(), 12);
}

export function getPrayerTimes(city: City, date: Date, method: CalculationMethodKey, offsetDays = 0): PrayerTimeItem[] {
  const { year, month, day } = datePartsInZone(date, city.timeZone);
  const calendarDate = new Date(Date.UTC(year, month - 1, day + offsetDays));
  const localDate = new Date(calendarDate.getUTCFullYear(), calendarDate.getUTCMonth(), calendarDate.getUTCDate(), 12);
  const params = methods[method]();
  const times = new PrayerTimes(new Coordinates(city.latitude, city.longitude), localDate, params);
  return PRAYERS.map(({ key, label }) => ({ key, label, date: times[timeFields[key]] as Date }));
}

export function getNextPrayer(city: City, method: CalculationMethodKey, now = new Date()) {
  for (let offset = 0; offset <= 1; offset += 1) {
    const prayers = getPrayerTimes(city, now, method, offset);
    const next = prayers.find((prayer) => prayer.date.getTime() > now.getTime());
    if (next) return next;
  }
  return getPrayerTimes(city, now, method, 2)[0];
}

export function formatClock(date: Date, timeZone: string): string {
  return new Intl.DateTimeFormat('ar', { timeZone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(date);
}

export function formatArabicDate(date: Date, timeZone: string): string {
  return new Intl.DateTimeFormat('ar', { timeZone, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(date);
}

export function formatCountdown(target: Date, now: Date): string {
  const seconds = Math.max(0, Math.floor((target.getTime() - now.getTime()) / 1000));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainder = seconds % 60;
  return [hours, minutes, remainder].map((value) => String(value).padStart(2, '0')).join(':');
}

export function nativeMethodName(method: CalculationMethodKey): string {
  return ({
    MWL: 'MUSLIM_WORLD_LEAGUE', Egyptian: 'EGYPTIAN', UmmAlQura: 'UMM_AL_QURA',
    Karachi: 'KARACHI', Dubai: 'DUBAI', Qatar: 'QATAR', Kuwait: 'KUWAIT',
    NorthAmerica: 'NORTH_AMERICA', Singapore: 'SINGAPORE', Turkey: 'TURKEY',
    MoonsightingCommittee: 'MOON_SIGHTING_COMMITTEE',
  } as const)[method];
}

export function settingsToNative(settings: AppSettings) {
  return {
    cityId: settings.city.id,
    latitude: settings.city.latitude,
    longitude: settings.city.longitude,
    timeZone: settings.city.timeZone,
    calculationMethod: nativeMethodName(settings.calculationMethod),
    prayers: Object.fromEntries(PRAYERS.map(({ key, nativeKey }) => [nativeKey, {
      enabled: settings.enabled[key],
      audioFile: ({ beautiful: 'beautiful-adhan.mp3', andrewler: 'azan-andrewler.mp3' } as const)[settings.audio[key]],
    }])),
  };
}
