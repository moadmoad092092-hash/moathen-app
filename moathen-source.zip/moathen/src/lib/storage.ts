import type { AppSettings, City, PrayerKey } from './types';
import { CITIES } from './cities';
import { PRAYERS } from './types';

const STORAGE_KEY = 'moathen.settings.v1';
const defaultPrayerRecord = <T,>(value: T): Record<PrayerKey, T> =>
  Object.fromEntries(PRAYERS.map(({ key }) => [key, value])) as Record<PrayerKey, T>;

export const DEFAULT_SETTINGS: AppSettings = {
  city: CITIES[0],
  calculationMethod: 'UmmAlQura',
  enabled: defaultPrayerRecord(true),
  audio: defaultPrayerRecord('beautiful'),
  webAudioEnabled: false,
};

export function loadSettings(): AppSettings {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(saved) as Partial<AppSettings>;
    const city = parsed.city as City | undefined;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      city: city?.timeZone && Number.isFinite(city.latitude) ? city : DEFAULT_SETTINGS.city,
      enabled: { ...DEFAULT_SETTINGS.enabled, ...parsed.enabled },
      audio: { ...DEFAULT_SETTINGS.audio, ...parsed.audio },
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(settings)); } catch { /* storage may be disabled */ }
}
