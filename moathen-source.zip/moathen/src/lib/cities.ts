import type { City } from './types';

export const CITIES: City[] = [
  { id: 'makkah', name: 'مكة المكرمة', country: 'السعودية', latitude: 21.3891, longitude: 39.8579, timeZone: 'Asia/Riyadh' },
  { id: 'madinah', name: 'المدينة المنورة', country: 'السعودية', latitude: 24.5247, longitude: 39.5692, timeZone: 'Asia/Riyadh' },
  { id: 'riyadh', name: 'الرياض', country: 'السعودية', latitude: 24.7136, longitude: 46.6753, timeZone: 'Asia/Riyadh' },
  { id: 'jeddah', name: 'جدة', country: 'السعودية', latitude: 21.4858, longitude: 39.1925, timeZone: 'Asia/Riyadh' },
  { id: 'dammam', name: 'الدمام', country: 'السعودية', latitude: 26.4207, longitude: 50.0888, timeZone: 'Asia/Riyadh' },
  { id: 'cairo', name: 'القاهرة', country: 'مصر', latitude: 30.0444, longitude: 31.2357, timeZone: 'Africa/Cairo' },
  { id: 'alexandria', name: 'الإسكندرية', country: 'مصر', latitude: 31.2001, longitude: 29.9187, timeZone: 'Africa/Cairo' },
  { id: 'casablanca', name: 'الدار البيضاء', country: 'المغرب', latitude: 33.5731, longitude: -7.5898, timeZone: 'Africa/Casablanca' },
  { id: 'rabat', name: 'الرباط', country: 'المغرب', latitude: 34.0209, longitude: -6.8416, timeZone: 'Africa/Casablanca' },
  { id: 'tunis', name: 'تونس', country: 'تونس', latitude: 36.8065, longitude: 10.1815, timeZone: 'Africa/Tunis' },
  { id: 'algiers', name: 'الجزائر', country: 'الجزائر', latitude: 36.7538, longitude: 3.0588, timeZone: 'Africa/Algiers' },
  { id: 'khartoum', name: 'الخرطوم', country: 'السودان', latitude: 15.5007, longitude: 32.5599, timeZone: 'Africa/Khartoum' },
  { id: 'amman', name: 'عمّان', country: 'الأردن', latitude: 31.9539, longitude: 35.9106, timeZone: 'Asia/Amman' },
  { id: 'jerusalem', name: 'القدس', country: 'فلسطين', latitude: 31.7683, longitude: 35.2137, timeZone: 'Asia/Hebron' },
  { id: 'beirut', name: 'بيروت', country: 'لبنان', latitude: 33.8938, longitude: 35.5018, timeZone: 'Asia/Beirut' },
  { id: 'doha', name: 'الدوحة', country: 'قطر', latitude: 25.2854, longitude: 51.531, timeZone: 'Asia/Qatar' },
  { id: 'kuwait', name: 'مدينة الكويت', country: 'الكويت', latitude: 29.3759, longitude: 47.9774, timeZone: 'Asia/Kuwait' },
  { id: 'manama', name: 'المنامة', country: 'البحرين', latitude: 26.2285, longitude: 50.586, timeZone: 'Asia/Bahrain' },
  { id: 'dubai', name: 'دبي', country: 'الإمارات', latitude: 25.2048, longitude: 55.2708, timeZone: 'Asia/Dubai' },
  { id: 'abudhabi', name: 'أبوظبي', country: 'الإمارات', latitude: 24.4539, longitude: 54.3773, timeZone: 'Asia/Dubai' },
  { id: 'muscat', name: 'مسقط', country: 'عُمان', latitude: 23.588, longitude: 58.3829, timeZone: 'Asia/Muscat' },
  { id: 'istanbul', name: 'إسطنبول', country: 'تركيا', latitude: 41.0082, longitude: 28.9784, timeZone: 'Europe/Istanbul' },
  { id: 'london', name: 'لندن', country: 'المملكة المتحدة', latitude: 51.5072, longitude: -0.1276, timeZone: 'Europe/London' },
  { id: 'paris', name: 'باريس', country: 'فرنسا', latitude: 48.8566, longitude: 2.3522, timeZone: 'Europe/Paris' },
  { id: 'newyork', name: 'نيويورك', country: 'الولايات المتحدة', latitude: 40.7128, longitude: -74.006, timeZone: 'America/New_York' },
  { id: 'jakarta', name: 'جاكرتا', country: 'إندونيسيا', latitude: -6.2088, longitude: 106.8456, timeZone: 'Asia/Jakarta' },
  { id: 'kualalumpur', name: 'كوالالمبور', country: 'ماليزيا', latitude: 3.139, longitude: 101.6869, timeZone: 'Asia/Kuala_Lumpur' },
  { id: 'karachi', name: 'كراتشي', country: 'باكستان', latitude: 24.8607, longitude: 67.0011, timeZone: 'Asia/Karachi' },
  { id: 'dhaka', name: 'دكا', country: 'بنغلاديش', latitude: 23.8103, longitude: 90.4125, timeZone: 'Asia/Dhaka' },
  { id: 'singapore', name: 'سنغافورة', country: 'سنغافورة', latitude: 1.3521, longitude: 103.8198, timeZone: 'Asia/Singapore' },
];

export function nearestCity(latitude: number, longitude: number): City {
  return CITIES.reduce((nearest, city) => {
    const distance = (candidate: City) => Math.hypot(candidate.latitude - latitude, (candidate.longitude - longitude) * Math.cos((latitude * Math.PI) / 180));
    return distance(city) < distance(nearest) ? city : nearest;
  }, CITIES[0]);
}
