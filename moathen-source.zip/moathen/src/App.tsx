import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { Geolocation } from '@capacitor/geolocation';
import { CITIES, nearestCity } from './lib/cities';
import { formatArabicDate, formatClock, formatCountdown, getNextPrayer, getPrayerTimes, settingsToNative } from './lib/prayer';
import { DEFAULT_SETTINGS, loadSettings, saveSettings } from './lib/storage';
import { PRAYERS, type AppSettings, type AudioChoice, type CalculationMethodKey, type City, type PrayerKey } from './lib/types';
import { MoathenScheduler, type PermissionState } from './native/scheduler';

const METHODS: { id: CalculationMethodKey; label: string }[] = [
  { id: 'UmmAlQura', label: 'أم القرى' },
  { id: 'Egyptian', label: 'الهيئة المصرية للمساحة' },
  { id: 'MWL', label: 'رابطة العالم الإسلامي' },
  { id: 'Karachi', label: 'كراتشي' },
  { id: 'Dubai', label: 'دبي' },
  { id: 'Qatar', label: 'قطر' },
  { id: 'Kuwait', label: 'الكويت' },
  { id: 'NorthAmerica', label: 'أمريكا الشمالية' },
  { id: 'Singapore', label: 'سنغافورة' },
  { id: 'Turkey', label: 'تركيا' },
  { id: 'MoonsightingCommittee', label: 'لجنة رؤية الهلال' },
];

const isAndroid = Capacitor.getPlatform() === 'android';

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [now, setNow] = useState(() => new Date());
  const [cityQuery, setCityQuery] = useState(settings.city.name);
  const [showCities, setShowCities] = useState(false);
  const [locationMessage, setLocationMessage] = useState('');
  const [nativePermission, setNativePermission] = useState<PermissionState | null>(null);
  const [nativeMessage, setNativeMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const previewRef = useRef<HTMLAudioElement | null>(null);
  const webAudioEnabled = settings.webAudioEnabled;

  const times = useMemo(() => getPrayerTimes(settings.city, now, settings.calculationMethod), [settings.city, now, settings.calculationMethod]);
  const nextPrayer = useMemo(() => getNextPrayer(settings.city, settings.calculationMethod, now), [settings.city, settings.calculationMethod, now]);

  useEffect(() => {
    saveSettings(settings);
    setCityQuery(settings.city.name);
  }, [settings]);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    const refresh = () => setNow(new Date());
    window.addEventListener('focus', refresh);
    document.addEventListener('visibilitychange', refresh);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('focus', refresh);
      document.removeEventListener('visibilitychange', refresh);
    };
  }, []);

  const syncNative = useCallback(async () => {
    if (!isAndroid) return;
    try {
      const result = await MoathenScheduler.scheduleAll(settingsToNative(settings));
      setNativePermission({ exactAlarmsAllowed: result.exactAlarmsAllowed, notificationAllowed: result.notificationAllowed });
      setNativeMessage(result.exactAlarmsAllowed
        ? `تم إعداد ${result.scheduled} تنبيهات محلية قادمة.`
        : 'يلزم السماح بالمنبهات والتذكيرات لتشغيل الأذان في موعده.');
    } catch (error) {
      setNativeMessage(error instanceof Error ? error.message : 'تعذر الوصول إلى جدولة Android.');
    }
  }, [settings]);

  useEffect(() => { void syncNative(); }, [syncNative]);

  useEffect(() => {
    if (!isAndroid) return;
    const refreshPermissionsAndSchedule = () => { void syncNative(); };
    window.addEventListener('focus', refreshPermissionsAndSchedule);
    document.addEventListener('visibilitychange', refreshPermissionsAndSchedule);
    return () => {
      window.removeEventListener('focus', refreshPermissionsAndSchedule);
      document.removeEventListener('visibilitychange', refreshPermissionsAndSchedule);
    };
  }, [syncNative]);

  useEffect(() => {
    if (isAndroid || !('serviceWorker' in navigator)) return;
    void navigator.serviceWorker.register('/sw.js').catch(() => undefined);
  }, []);

  useEffect(() => {
    if (isAndroid || !webAudioEnabled || !settings.enabled[nextPrayer.key]) return;
    const delay = Math.max(0, nextPrayer.date.getTime() - Date.now());
    const timer = window.setTimeout(() => {
      if (document.visibilityState !== 'visible') return;
      const marker = `moathen.web.lastFired.${nextPrayer.key}.${nextPrayer.date.getTime()}`;
      if (sessionStorage.getItem(marker)) return;
      sessionStorage.setItem(marker, '1');
      const audioChoice = settings.audio[nextPrayer.key];
      const file = audioPath(nextPrayer.key, audioChoice);
      const player = new Audio(file);
      void player.play().catch(() => setLocationMessage('منع المتصفح التشغيل التلقائي؛ افتح الصفحة واضغط زر تفعيل صوت الويب.'));
    }, delay);
    return () => window.clearTimeout(timer);
  }, [isAndroid, webAudioEnabled, nextPrayer.key, nextPrayer.date.getTime(), settings.enabled, settings.audio]);

  const updateSettings = (patch: Partial<AppSettings>) => setSettings((previous) => ({ ...previous, ...patch }));
  const updatePrayer = <K extends 'enabled' | 'audio'>(kind: K, prayer: PrayerKey, value: AppSettings[K][PrayerKey]) => {
    setSettings((previous) => ({ ...previous, [kind]: { ...previous[kind], [prayer]: value } }));
  };

  const chooseCity = (city: City) => {
    updateSettings({ city });
    setCityQuery(city.name);
    setShowCities(false);
    setLocationMessage('');
  };

  const locate = async () => {
    setBusy(true);
    setLocationMessage('جارٍ طلب إذن الموقع…');
    try {
      let latitude: number;
      let longitude: number;
      if (isAndroid) {
        const position = await Geolocation.getCurrentPosition({ enableHighAccuracy: false, timeout: 15000 });
        latitude = position.coords.latitude;
        longitude = position.coords.longitude;
      } else {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          if (!navigator.geolocation) return reject(new Error('الموقع غير متاح في هذا المتصفح.'));
          navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: false, timeout: 15000, maximumAge: 300000 });
        });
        latitude = position.coords.latitude;
        longitude = position.coords.longitude;
      }
      const closest = nearestCity(latitude, longitude);
      const distance = Math.hypot(closest.latitude - latitude, closest.longitude - longitude);
      const zone = Intl.DateTimeFormat().resolvedOptions().timeZone || closest.timeZone;
      const city = distance < 0.7
        ? { ...closest, latitude, longitude, timeZone: zone }
        : { id: 'current-location', name: 'موقعي الحالي', country: '', latitude, longitude, timeZone: zone };
      chooseCity(city);
      setLocationMessage('حُدّث الموقع وحُفظ على هذا الجهاز.');
    } catch (error) {
      const message = error instanceof Error && error.message ? error.message : 'تعذر تحديد الموقع؛ اختر المدينة يدويًا.';
      setLocationMessage(message.includes('denied') ? 'لم يُمنح إذن الموقع. يمكنك اختيار المدينة يدويًا.' : message);
    } finally {
      setBusy(false);
    }
  };

  const requestExactPermission = async () => {
    try {
      const state = await MoathenScheduler.getPermissionState();
      setNativePermission(state);
      if (!state.exactAlarmsAllowed) await MoathenScheduler.requestExactAlarmPermission();
      await MoathenScheduler.requestNotificationPermission();
      setNativeMessage('ارجع إلى التطبيق بعد منح الإذن لإعادة فحص الجدولة.');
    } catch {
      setNativeMessage('لم نتمكن من فتح إعدادات التنبيهات. يمكنك منح الإذن من إعدادات Android للتطبيق.');
    }
  };

  const preview = async (prayer: PrayerKey) => {
    const file = audioPath(prayer, settings.audio[prayer]);
    previewRef.current?.pause();
    const player = new Audio(file);
    previewRef.current = player;
    void player.play().catch(() => setLocationMessage('تعذر تشغيل الملف؛ تحقق من إعدادات الصوت في المتصفح.'));
  };

  const cityMatches = CITIES.filter((city) => `${city.name} ${city.country}`.includes(cityQuery.trim())).slice(0, 8);
  const methodName = METHODS.find(({ id }) => id === settings.calculationMethod)?.label ?? 'أم القرى';

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="مؤذّن — الصفحة الرئيسية">
          <img src="/icons/moathen-mark-512.png" alt="" className="brand-mark" />
          <span className="brand-name">مؤذّن<small>MOATHEN</small></span>
        </a>
        <div className="topbar-actions">
          <button className="outline-button locate-button" onClick={() => void locate()} disabled={busy}>
            <span aria-hidden="true">⌖</span>{busy ? 'جارٍ التحديد…' : 'تحديد موقعي'}
          </button>
          <span className="offline-chip"><i /> يعمل محليًا</span>
        </div>
      </header>

      <main id="top">
        <section className="hero-card" aria-labelledby="hero-title">
          <div className="hero-ornament" aria-hidden="true"><span>☾</span><b /></div>
          <div className="hero-head">
            <div className="city-picker-wrap">
              <label htmlFor="city-search" className="eyebrow">موقع المواقيت</label>
              <div className="city-picker">
                <span className="pin" aria-hidden="true">⌖</span>
                <input
                  id="city-search"
                  value={cityQuery}
                  onChange={(event) => { setCityQuery(event.target.value); setShowCities(true); }}
                  onFocus={() => setShowCities(true)}
                  onBlur={() => window.setTimeout(() => setShowCities(false), 160)}
                  aria-label="ابحث عن مدينة"
                  autoComplete="off"
                />
                <span className="chevron" aria-hidden="true">⌄</span>
                {showCities && cityMatches.length > 0 && (
                  <div className="city-menu" role="listbox">
                    {cityMatches.map((city) => <button key={city.id} role="option" aria-selected={city.id === settings.city.id} onMouseDown={(event) => event.preventDefault()} onClick={() => chooseCity(city)}>{city.name}<small>{city.country}</small></button>)}
                  </div>
                )}
              </div>
            </div>
            <p className="hijri-date">{formatArabicDate(now, settings.city.timeZone)}</p>
          </div>

          <div className="hero-content">
            <div className="next-label"><span className="live-dot" /> الصلاة القادمة</div>
            <h1 id="hero-title">{nextPrayer.label}</h1>
            <p className="next-time">{formatClock(nextPrayer.date, settings.city.timeZone)}</p>
            <div className="countdown-wrap">
              <span>الوقت المتبقي</span>
              <time className="countdown" dateTime={nextPrayer.date.toISOString()}>{formatCountdown(nextPrayer.date, now)}</time>
            </div>
          </div>
          <div className="hero-footer">
            <span>طريقة الحساب: {methodName}</span>
            <span>{settings.city.timeZone}</span>
          </div>
        </section>

        <div className="context-message" aria-live="polite">{locationMessage}</div>

        <section className="prayer-section" aria-labelledby="prayers-title">
          <div className="section-heading">
            <div><p className="eyebrow">مواعيد اليوم</p><h2 id="prayers-title">الصلوات الخمس</h2></div>
            <span className="section-date">بتوقيت {settings.city.name}</span>
          </div>
          <div className="prayer-list">
            {times.map((prayer, index) => {
              const isNext = prayer.key === nextPrayer.key && prayer.date.getTime() === nextPrayer.date.getTime();
              return (
                <article key={prayer.key} className={`prayer-row ${isNext ? 'is-next' : ''}`}>
                  <div className="prayer-sequence"><span className="sequence-point">{String(index + 1).padStart(2, '0')}</span><i /></div>
                  <div className="prayer-main"><h3>{prayer.label}</h3><p>{isNext ? 'الصلاة التالية' : 'موعد الصلاة'}</p></div>
                  <time className="prayer-clock" dateTime={prayer.date.toISOString()}>{formatClock(prayer.date, settings.city.timeZone)}</time>
                  {isNext && <span className="upcoming-pill">القادمة</span>}
                </article>
              );
            })}
          </div>
        </section>

        <section className="settings-section" aria-labelledby="settings-title">
          <div className="section-heading settings-heading">
            <div><p className="eyebrow">على جهازك</p><h2 id="settings-title">إعدادات الأذان</h2></div>
            <select aria-label="طريقة حساب مواقيت الصلاة" className="method-select" value={settings.calculationMethod} onChange={(event) => updateSettings({ calculationMethod: event.target.value as CalculationMethodKey })}>
              {METHODS.map((method) => <option value={method.id} key={method.id}>{method.label}</option>)}
            </select>
          </div>
          <div className="settings-list">
            {PRAYERS.map(({ key, label }) => (
              <div className="setting-row" key={key}>
                <div className="setting-prayer"><span className={`toggle ${settings.enabled[key] ? 'on' : ''}`} aria-hidden="true"><i /></span><strong>{label}</strong></div>
                <label className="audio-label" htmlFor={`audio-${key}`}>الصوت</label>
                <select id={`audio-${key}`} className="audio-select" value={settings.audio[key]} onChange={(event) => updatePrayer('audio', key, event.target.value as AudioChoice)}>
                  <option value="beautiful">Beautiful Adhan — CC0</option>
                  <option value="andrewler">Azan — Andrewler</option>
                </select>
                <button className="preview-button" onClick={() => void preview(key)} aria-label={`معاينة أذان ${label}`} title="تشغيل معاينة">▶</button>
                <button className={`switch ${settings.enabled[key] ? 'checked' : ''}`} role="switch" aria-checked={settings.enabled[key]} aria-label={`${settings.enabled[key] ? 'إيقاف' : 'تشغيل'} أذان ${label}`} onClick={() => updatePrayer('enabled', key, !settings.enabled[key])}><i /></button>
              </div>
            ))}
          </div>
          {isAndroid ? (
            <div className={`native-status ${nativePermission?.exactAlarmsAllowed ? 'ready' : 'needs-permission'}`}>
              <div><strong>{nativePermission?.exactAlarmsAllowed ? 'الجدولة المحلية مفعّلة' : 'تفعيل الأذان عند قفل الشاشة'}</strong><p>{nativeMessage || 'تحتاج جدولة Android إلى إذن المنبهات والتذكيرات.'}</p></div>
              {!nativePermission?.exactAlarmsAllowed && <button className="primary-button" onClick={() => void requestExactPermission()}>فتح إعدادات الإذن</button>}
            </div>
          ) : (
            <div className="web-status">
              <div><strong>نسخة المتصفح</strong><p>قد يوقف المتصفح المؤقت والصوت عند تعليق التبويب أو إغلاقه؛ لا يضمن الويب الأذان في الخلفية.</p></div>
              <button className={`primary-button ${webAudioEnabled ? 'activated' : ''}`} onClick={() => updateSettings({ webAudioEnabled: !webAudioEnabled})}>{webAudioEnabled ? 'صوت الويب مفعّل' : 'السماح بالتنبيه عند فتح الصفحة'}</button>
            </div>
          )}
        </section>

        <footer className="page-footer"><span>مؤذّن · مواقيت تُحسب على جهازك</span><span>تُحفظ تفضيلاتك محليًا</span></footer>
      </main>
      <audio hidden ref={previewRef} />
    </div>
  );
}

function audioPath(_prayer: PrayerKey, choice: AudioChoice) {
  return ({ beautiful: '/audio/beautiful-adhan.mp3', andrewler: '/audio/azan-andrewler.mp3' } as const)[choice];
}

void DEFAULT_SETTINGS;
