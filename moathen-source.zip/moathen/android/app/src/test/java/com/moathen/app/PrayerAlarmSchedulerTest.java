package com.moathen.app;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class PrayerAlarmSchedulerTest {
    @Test
    public void returnsUpcomingNativeAdhanForEveryPrayerAndRollsForwardOneDay() {
        String[] prayers = { "FAJR", "DHUHR", "ASR", "MAGHRIB", "ISHA" };
        long now = System.currentTimeMillis();
        for (String prayer : prayers) {
            long first = PrayerAlarmScheduler.nextPrayerEpoch(
                    21.3891, 39.8579, "Asia/Riyadh", "UMM_AL_QURA", prayer, now);
            assertTrue(prayer + " should have a future trigger", first > now);
            long nextDay = PrayerAlarmScheduler.nextPrayerEpoch(
                    21.3891, 39.8579, "Asia/Riyadh", "UMM_AL_QURA", prayer, first + 1_000L);
            assertTrue(prayer + " should roll to the next day", nextDay > first);
            assertTrue(prayer + " should recur roughly one day later", nextDay - first > 20L * 60L * 60L * 1_000L);
        }
    }
}
