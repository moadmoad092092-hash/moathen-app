package com.moathen.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.content.ContextCompat;

import org.json.JSONObject;

public class PrayerAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String prayer = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_PRAYER);
        String audio = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_AUDIO);
        if (prayer == null || audio == null) return;
        JSONObject config = PrayerAlarmScheduler.readConfig(context);
        if (config == null) return;
        JSONObject prayers = config.optJSONObject("prayers");
        JSONObject settings = prayers == null ? null : prayers.optJSONObject(prayer);
        if (settings == null || !settings.optBoolean("enabled", false)) {
            try { PrayerAlarmScheduler.scheduleAll(context); } catch (Exception ignored) {}
            return;
        }
        Intent playback = new Intent(context, AzanPlaybackService.class)
                .setAction(AzanPlaybackService.ACTION_PLAY)
                .putExtra(PrayerAlarmScheduler.EXTRA_PRAYER, prayer)
                .putExtra(PrayerAlarmScheduler.EXTRA_AUDIO, audio);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(context, playback);
            else context.startService(playback);
        } catch (Exception ignored) {
            // Android may block playback if a manufacturer-specific policy or permission prevents the FGS.
        }
        try { PrayerAlarmScheduler.scheduleAll(context); } catch (Exception ignored) {}
    }
}
