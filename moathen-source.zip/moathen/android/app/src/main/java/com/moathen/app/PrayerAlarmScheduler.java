package com.moathen.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.content.SharedPreferences;

import com.batoulapps.adhan2.CalculationMethod;
import com.batoulapps.adhan2.Coordinates;
import com.batoulapps.adhan2.PrayerTimes;
import com.batoulapps.adhan2.data.DateComponents;
import kotlin.time.Instant;

import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;

final class PrayerAlarmScheduler {
    static final String PREFS = "moathen.local.scheduler";
    static final String CONFIG = "configuration";
    static final String EXTRA_PRAYER = "prayer";
    static final String EXTRA_AUDIO = "audioFile";
    private static final List<String> PRAYERS = Arrays.asList("FAJR", "DHUHR", "ASR", "MAGHRIB", "ISHA");

    private PrayerAlarmScheduler() {}

    static int scheduleAll(Context context) throws JSONException {
        JSONObject config = readConfig(context);
        if (config == null) return 0;
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        for (String prayer : PRAYERS) alarms.cancel(pendingIntent(context, prayer));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarms.canScheduleExactAlarms()) return 0;
        int scheduled = 0;
        for (String prayer : PRAYERS) {
            JSONObject settings = config.optJSONObject("prayers");
            JSONObject prayerSettings = settings == null ? null : settings.optJSONObject(prayer);
            if (prayerSettings == null || !prayerSettings.optBoolean("enabled", false)) continue;
            String audio = prayerSettings.optString("audioFile", "beautiful-adhan.mp3");
            if (!audio.matches("[A-Za-z0-9._-]+\\.mp3")) audio = "beautiful-adhan.mp3";
            long trigger = nextPrayerEpoch(config, prayer, System.currentTimeMillis() + 1500L);
            if (trigger <= 0) continue;
            Intent intent = new Intent(context, PrayerAlarmReceiver.class)
                    .setAction("com.moathen.app.PRAYER_" + prayer)
                    .setData(Uri.parse("moathen://prayer/" + prayer))
                    .putExtra(EXTRA_PRAYER, prayer)
                    .putExtra(EXTRA_AUDIO, audio);
            PendingIntent operation = PendingIntent.getBroadcast(context, requestCode(prayer), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, operation);
            scheduled++;
        }
        return scheduled;
    }

    static JSONObject readConfig(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(CONFIG, null);
        if (raw == null) return null;
        try { return new JSONObject(raw); } catch (JSONException ignored) { return null; }
    }

    static void writeConfig(Context context, JSONObject config) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(CONFIG, config.toString()).apply();
    }

    static PendingIntent pendingIntent(Context context, String prayer) {
        Intent intent = new Intent(context, PrayerAlarmReceiver.class)
                .setAction("com.moathen.app.PRAYER_" + prayer)
                .setData(Uri.parse("moathen://prayer/" + prayer));
        return PendingIntent.getBroadcast(context, requestCode(prayer), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static int requestCode(String prayer) { return PRAYERS.indexOf(prayer) + 410; }

    private static long nextPrayerEpoch(JSONObject config, String prayer, long afterMillis) {
        try {
            return nextPrayerEpoch(config.getDouble("latitude"), config.getDouble("longitude"),
                    config.getString("timeZone"), config.getString("calculationMethod"), prayer, afterMillis);
        } catch (Exception ignored) { return -1L; }
    }

    static long nextPrayerEpoch(double latitude, double longitude, String zoneName,
                                String methodName, String prayer, long afterMillis) {
        try {
            ZoneId zone = ZoneId.of(zoneName);
            CalculationMethod method = CalculationMethod.valueOf(methodName);
            LocalDate today = LocalDate.now(zone);
            for (int offset = 0; offset <= 3; offset++) {
                LocalDate day = today.plusDays(offset);
                DateComponents date = new DateComponents(day.getYear(), day.getMonthValue(), day.getDayOfMonth());
                PrayerTimes times = new PrayerTimes(new Coordinates(latitude, longitude), date, method.getParameters());
                Instant instant;
                switch (prayer) {
                    case "FAJR": instant = times.getFajr(); break;
                    case "DHUHR": instant = times.getDhuhr(); break;
                    case "ASR": instant = times.getAsr(); break;
                    case "MAGHRIB": instant = times.getMaghrib(); break;
                    case "ISHA": instant = times.getIsha(); break;
                    default: return -1L;
                }
                long epoch = instant.toEpochMilliseconds();
                if (epoch > afterMillis) return epoch;
            }
        } catch (Exception ignored) { return -1L; }
        return -1L;
    }
}
