package com.moathen.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class AzanPlaybackService extends Service {
    static final String ACTION_PLAY = "com.moathen.app.PLAY_ADHAN";
    private static final String CHANNEL_ID = "moathen_azan_playback";
    private static final int NOTIFICATION_ID = 9104;
    private MediaPlayer player;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "الأذان", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("تشغيل الأذان عند حلول وقت الصلاة");
            channel.setSound(null, null);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !ACTION_PLAY.equals(intent.getAction())) { stopSelf(startId); return START_NOT_STICKY; }
        String prayer = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_PRAYER);
        String fileName = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_AUDIO);
        if (prayer == null || fileName == null || !fileName.matches("[A-Za-z0-9._-]+\\.mp3")) { stopSelf(startId); return START_NOT_STICKY; }
        startInForeground(prayer);
        releasePlayer();
        try {
            File audio = new File(getCacheDir(), fileName);
            if (!audio.isFile() || audio.length() == 0) {
                try (InputStream input = getAssets().open("public/audio/" + fileName);
                     FileOutputStream output = new FileOutputStream(audio)) {
                    byte[] buffer = new byte[32 * 1024];
                    int read;
                    while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                }
            }
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            player.setDataSource(audio.getAbsolutePath());
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(mediaPlayer -> stopSelf(startId));
            player.setOnErrorListener((mediaPlayer, what, extra) -> { stopSelf(startId); return true; });
            player.prepareAsync();
        } catch (Exception error) {
            stopSelf(startId);
        }
        return START_NOT_STICKY;
    }

    private void startInForeground(String prayer) {
        String[] names = { "FAJR", "DHUHR", "ASR", "MAGHRIB", "ISHA" };
        String[] arabic = { "الفجر", "الظهر", "العصر", "المغرب", "العشاء" };
        String title = "حان وقت الصلاة";
        for (int i = 0; i < names.length; i++) if (names[i].equals(prayer)) title = "حان وقت صلاة " + arabic[i];
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent content = launch == null ? null : PendingIntent.getActivity(this, 9401, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText("مؤذّن · يُشغّل التسجيل الصوتي المحلي")
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setOnlyAlertOnce(true);
        if (content != null) builder.setContentIntent(content);
        Notification notification = builder.build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.setOnCompletionListener(null); player.reset(); player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    @Override public void onDestroy() {
        releasePlayer();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
