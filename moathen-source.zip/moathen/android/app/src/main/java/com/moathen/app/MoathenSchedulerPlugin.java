package com.moathen.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import org.json.JSONException;
import org.json.JSONObject;

@CapacitorPlugin(name = "MoathenScheduler", permissions = {
        @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS })
})
public class MoathenSchedulerPlugin extends Plugin {

    @PluginMethod
    public void scheduleAll(PluginCall call) {
        try {
            JSONObject config = call.getData();
            if (config == null || !config.has("latitude") || !config.has("timeZone")) {
                call.reject("إعدادات الموقع أو المنطقة الزمنية غير مكتملة.");
                return;
            }
            PrayerAlarmScheduler.writeConfig(getContext(), config);
            int scheduled = PrayerAlarmScheduler.scheduleAll(getContext());
            JSObject result = permissionState();
            result.put("scheduled", scheduled);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("تعذرت جدولة أوقات الصلاة محليًا.", error);
        }
    }

    @PluginMethod
    public void getPermissionState(PluginCall call) {
        call.resolve(permissionState());
    }

    @PluginMethod
    public void requestExactAlarmPermission(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                JSObject result = new JSObject();
                result.put("openedSettings", false);
                call.resolve(result);
                return;
            }
            AlarmManager alarms = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
            if (alarms.canScheduleExactAlarms()) {
                JSObject result = new JSObject();
                result.put("openedSettings", false);
                call.resolve(result);
                return;
            }
            Intent settings = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getContext().getPackageName()));
            getActivity().startActivity(settings);
            JSObject result = new JSObject();
            result.put("openedSettings", true);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("تعذر فتح إعدادات المنبهات الدقيقة.", error);
        }
    }

    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                || ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            JSObject result = new JSObject();
            result.put("granted", NotificationManagerCompat.from(getContext()).areNotificationsEnabled());
            call.resolve(result);
        } else {
            requestPermissionForAlias("notifications", call, "notificationsPermissionResult");
        }
    }

    @PermissionCallback
    private void notificationsPermissionResult(PluginCall call) {
        JSObject result = new JSObject();
        result.put("granted", NotificationManagerCompat.from(getContext()).areNotificationsEnabled());
        call.resolve(result);
    }

    private JSObject permissionState() {
        AlarmManager alarms = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
        boolean exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarms.canScheduleExactAlarms();
        JSObject result = new JSObject();
        result.put("exactAlarmsAllowed", exactAllowed);
        result.put("notificationAllowed", NotificationManagerCompat.from(getContext()).areNotificationsEnabled());
        return result;
    }
}
