package com.moathen.app;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONObject;

import java.time.ZoneId;

public class RescheduleReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        JSONObject config = PrayerAlarmScheduler.readConfig(context);
        if (config == null) return;
        if (Intent.ACTION_TIMEZONE_CHANGED.equals(intent.getAction())) {
            if ("current-location".equals(config.optString("cityId"))) {
                try {
                    config.put("timeZone", ZoneId.systemDefault().getId());
                    PrayerAlarmScheduler.writeConfig(context, config);
                } catch (Exception ignored) {}
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED.equals(intent.getAction())) {
            AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (!alarms.canScheduleExactAlarms()) return;
        }
        try { PrayerAlarmScheduler.scheduleAll(context); } catch (Exception ignored) {}
    }
}
