package com.moathen.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        registerPlugin(MoathenSchedulerPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
