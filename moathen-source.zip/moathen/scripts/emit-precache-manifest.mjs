import { readdir, writeFile } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';

async function walk(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const results = [];
  for (const entry of entries) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) results.push(...await walk(path));
    else if (entry.isFile() && !entry.name.endsWith('.map')) results.push(path);
  }
  return results;
}

const files = (await walk('dist/assets'))
  .map((path) => `/${relative('dist', path).split(sep).join('/')}`)
  .sort();
const manifest = {
  assets: [
    '/', '/manifest.webmanifest', '/precache-manifest.json',
    '/icons/moathen-mark-192.png', '/icons/moathen-mark-512.png',
    '/audio/beautiful-adhan.mp3', '/audio/azan-andrewler.mp3',
    ...files,
  ],
};
await writeFile('dist/precache-manifest.json', `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`Generated PWA precache manifest with ${manifest.assets.length} URLs.`);
